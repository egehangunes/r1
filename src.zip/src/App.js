import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import FormPage from './FormPage';
import TablePage from './TablePage';
import EditFormPage from './EditFormPage';

function App() {
  return (
    <Router>
      <div className="App">
        <header className="App-header">
          <h1>Form ve Tablo Uygulaması</h1>
        </header>
        <Routes>
          <Route path="/" element={<FormPage />} />
          <Route path="/table" element={<TablePage />} />
          <Route path="/edit/:index" element={<EditFormPage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
